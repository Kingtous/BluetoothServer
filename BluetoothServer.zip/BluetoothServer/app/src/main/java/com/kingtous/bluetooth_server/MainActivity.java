package com.kingtous.bluetooth_server;

import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.DialogInterface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import java.io.IOException;
import java.util.List;
import java.util.UUID;

import androidx.annotation.NonNull;
import pub.devrel.easypermissions.EasyPermissions;

public class MainActivity extends AppCompatActivity implements EasyPermissions.PermissionCallbacks{

    java.util.UUID uuid;

    TextView message_view;

    BluetoothManager bluetoothManager;
    BluetoothAdapter bluetoothAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        message_view=findViewById(R.id.bluetooth_message);

        bluetoothManager=(BluetoothManager) getSystemService(Activity.BLUETOOTH_SERVICE);
        bluetoothAdapter=bluetoothManager.getAdapter();
        if (bluetoothAdapter==null)
        {
            new AlertDialog.Builder(this)
                    .setTitle("错误")
                    .setMessage("设备无蓝牙设备")
                    .setNegativeButton("关闭软件", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            finish();
                        }
                    })
                    .show();
        }

        uuid=UUID.fromString(getString(R.string.UUID));

        listen();
    }


    private void listen()
    {
        try {
            BluetoothServerSocket socket=bluetoothAdapter.listenUsingRfcommWithServiceRecord("name",uuid);
            socket.accept();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }



    @Override
    public void onPermissionsGranted(int requestCode, @NonNull List<String> perms) {

    }

    @Override
    public void onPermissionsDenied(int requestCode, @NonNull List<String> perms) {

    }
}
